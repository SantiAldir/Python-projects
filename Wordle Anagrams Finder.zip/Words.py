#functions that recieves a word and return the word split to characters
#@param word1 a string to represent the word recieved
#@return dic1 a dictionary of the character and how many times each character appears in the word
def wordToDic(word1=""):
    dic1={}
    for c in word1:
        if c in dic1.keys():
            dic1[c]= dic1[c]+1
        else:
            dic1.update({c:1})
    return dic1

#function to compare if 2 list has the same members
#@param list1- the first list
#@param list2- the second list
#@return True if both lists has the same members. False otherwise
def compareLists(list1, list2):
    for k in list1:
        if not(k in list2):
            return False
    for k in list2:
        if not (k in list1):
            return False
    return True

#function to compare of 2 dictionaries has the same keys and values per keys
#@param dic1- the first dictionary
#@param dic2- the second dictionary
#@return True if both dictionaries has the same keys and values per keys. False otherwise
def compareDictionaries(dic1, dic2):
    if not(compareLists(dic1.keys(), dic2.keys())):
        return False
    for k in dic1.keys():
        if dic1[k]!=dic2[k]:
            return False
    return True

#function to determine if certain string is a valid word- contains only alphabetical characters
#@param st1- the string to check
#@return True if the string is a valid word. False otherwise
def isWord(st1=""):
    s=""
    for c in range(ord('a'), ord('z')+1):
        s+=chr(c)
    for c in st1.lower():
        if not (c in s):
            return False
    return True

#function to determine if 2 words are anagrams
#@param word1- the first word
#@param word2- the second word
#@retrun True if both words are anagrams, False otherwise
def isAnagram(word1, word2):
    if not(isWord(word1) or isWord(word2)):
        return False
    if len(word1)!=len(word2):
        return False
    dic1=wordToDic(word1.lower())
    dic2=wordToDic(word2.lower())
    return compareDictionaries(dic1, dic2)

#function that recieves a list of words and sort it to anagrams and how many times each anagram is in the list
#@param list1 the list of words
#@return anags- a dictionary of anagrams as keys, and the amount of their appearance as values
def sortAnagrams(list1):
    anags={}
    for word in list1:
        if isWord(word):
            for k in anags.keys():
                if isAnagram(word,k):
                    anags[k]=anags[k]+1
                    break
            else:
                anags.update({word:1})
    return anags

#function that recieves a dictionary and return its keys as list
#@param dic1 the dictionary
#@return l1 list of all the keys
def keysToList(dic1):
    l1=[]
    for k in dic1.keys():
        l1.append(k)
    return l1

#function that recieves a list of words and returns a list of the words with most of the anagrams
#@param list1 list of words
#@return MCA a list of the Most Common Anagrams
def findMostCommonAnagrams(list1):
    anags=sortAnagrams(list1)
    keyslist=keysToList(anags)
    MCA=[keyslist[0]]
    for k in keyslist[1:]:
        if anags[k]>anags[MCA[0]]:
            MCA=[k]
        elif anags[k]==anags[MCA[0]]:
            MCA.append(k)
    return MCA

#function to provide infromation on certain words from the list
#@param word1 the word to learn about
#@param list1 the list of words
#@print the amount of anagrams of the word in the list and the anagrams
def infoOfWord(word1, list1):
    anags=[]
    for word in list1:
        if isAnagram(word1, word):
            anags.append(word)
    print("the word "+ word1 + " has " +str(len(anags))+" anagrams in the list and are:")
    print(anags)

#function that provides information on the most common anagrams from given list
#@param list1 the list of words to study
#@print the information on each word from the most common anagrams
def infoOnMostCommonAnagrams(list1):
    MCA=findMostCommonAnagrams(list1)
    for word in MCA:
        infoOfWord(word,list1)

#function to isolate all the none alphabetical characters from a given string
#@param st a full string
#@return s a list of all the none alphabetical characters in st
def isolateNonABChars(st=""):
    s=[]
    for c in st:
        if not (str(c).isalpha()):
            s.append(c)
    return s

#function that takes a list of strings and returns a long string of the words from the list seperated by spaces
#@paraam list1 list of words
#@return s string of the words from list1 seperated by spaces
def listToString(list1):
    s=""
    for l in list1:
        s+= l
        s+=" "
    return s[:len(s)-1]

#function that recieves a string and extract the alphabetical words from it to single list
#@param st a string to extract words to
#@return l a list of alphabetical words
def toWordsList(st=""):
    l=[]
    nabc=isolateNonABChars(st)
    for c in nabc:
        l=st.split(c)
        st=listToString(l)
    l=st.split(" ")
    cleaninglist=l
    l=[]
    for word in cleaninglist:
        if word.isalpha():
            l.append(word)
    return l

#function to remove all repeated words in words list
#@param list1 list of words
#@return l list of the same words without any repeating word
def reduceDoubles(list1=[]):
    temp=wordToDic(list1)
    l=[]
    for word in temp.keys():
        if word.lower() not in l:
            l.append(word.lower())
    return l

#the final function to find the most common anagrams in a txt file and print the information on the anagrams
#@param filename the location and file name of the file to test
#@print the most common anagrams in the txt file, the amount of anagrams each has, and their anagrams
def doTheThing(filename):
    txt=""
    with open(filename) as f:
       txt=f.read()
    words=toWordsList(txt)
    words=reduceDoubles(words)
    infoOnMostCommonAnagrams(words)

#find all the anagrams of certain word in the file
#@param word the word i want to know its anagrams
#@param filename the location and file name of the text file
#@print all the anagrams of the word and the amount of their anagrams
def doThethingOnOneWord(word, filename):
    wl=[]
    with open(filename) as f:
        txt=f.read()
        wl=toWordsList(txt)
    wl=reduceDoubles(wl)
    infoOfWord(word, wl)

#doTheThing("wordle_word_list.txt")
#doThethingOnOneWord("acter", "wordle word list.txt")